"use client"

import { createContext, useContext, useState, ReactNode } from "react"

export type ProfileType = "cliente" | "motorista" | "gerente"

interface User {
  id: string
  name: string
  email: string
  phone: string
  type: ProfileType
  avatar?: string
}

interface ProfileContextType {
  profile: ProfileType
  setProfile: (profile: ProfileType) => void
  user: User | null
  setUser: (user: User | null) => void
  isLoading: boolean
  setIsLoading: (loading: boolean) => void
}

const ProfileContext = createContext<ProfileContextType | undefined>(undefined)

export function ProfileProvider({ children }: { children: ReactNode }) {
  const [profile, setProfile] = useState<ProfileType>("cliente")
  const [user, setUser] = useState<User | null>({
    id: "1",
    name: "Carlos Silva",
    email: "carlos@email.com",
    phone: "(12) 99999-9999",
    type: "cliente",
  })
  const [isLoading, setIsLoading] = useState(false)

  return (
    <ProfileContext.Provider
      value={{
        profile,
        setProfile,
        user,
        setUser,
        isLoading,
        setIsLoading,
      }}
    >
      {children}
    </ProfileContext.Provider>
  )
}

export function useProfile() {
  const context = useContext(ProfileContext)
  if (context === undefined) {
    throw new Error("useProfile must be used within a ProfileProvider")
  }
  return context
}
