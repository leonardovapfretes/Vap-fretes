"use client"

import { cn } from "@/lib/utils"

interface VapFretesLogoProps {
  className?: string
  size?: "sm" | "md" | "lg"
  showText?: boolean
}

export function VapFretesLogo({ className, size = "md", showText = true }: VapFretesLogoProps) {
  const sizes = {
    sm: { svg: 32, text: "text-xs" },
    md: { svg: 48, text: "text-sm" },
    lg: { svg: 80, text: "text-base" },
  }

  const { svg: svgSize, text: textSize } = sizes[size]

  return (
    <div className={cn("flex items-center gap-2", className)}>
      <svg
        width={svgSize}
        height={svgSize}
        viewBox="0 0 96 96"
        xmlns="http://www.w3.org/2000/svg"
        className="flex-shrink-0"
      >
        <defs>
          <linearGradient id="vap-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#ff8c00" />
            <stop offset="100%" stopColor="#c44200" />
          </linearGradient>
        </defs>
        <rect width="96" height="96" rx="22" fill="url(#vap-gradient)" />
        <path
          d="M18 20 L38 72 L48 72 L58 72 L78 20 L64 20 L48 62 L32 20 Z"
          fill="white"
          opacity="0.95"
        />
        <path
          d="M52 18 L42 44 L50 44 L40 74 L62 38 L54 38 Z"
          fill="#ff6b00"
        />
        <path
          d="M52 18 L42 44 L50 44 L40 74 L62 38 L54 38 Z"
          fill="white"
          opacity="0.3"
        />
      </svg>
      {showText && (
        <div className="flex flex-col">
          <span className={cn("font-black tracking-wider text-primary", textSize)}>
            VAP
          </span>
          <span className={cn("font-bold tracking-widest text-foreground -mt-1", textSize)}>
            FRETES
          </span>
        </div>
      )}
    </div>
  )
}
