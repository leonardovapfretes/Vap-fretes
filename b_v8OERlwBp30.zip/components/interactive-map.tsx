"use client"

import { useEffect, useRef, useState } from "react"
import { cn } from "@/lib/utils"
import { Locate, Move, Maximize2, Minimize2 } from "lucide-react"
import { Button } from "@/components/ui/button"

interface InteractiveMapProps {
  className?: string
  showControls?: boolean
  isFullscreen?: boolean
  onToggleFullscreen?: () => void
  markers?: Array<{
    id: string
    lat: number
    lng: number
    label?: string
    type?: "origin" | "destination" | "driver"
  }>
}

export function InteractiveMap({
  className,
  showControls = true,
  isFullscreen = false,
  onToggleFullscreen,
  markers = [],
}: InteractiveMapProps) {
  const mapRef = useRef<HTMLDivElement>(null)
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    // Simulate map loading
    const timer = setTimeout(() => {
      setIsLoaded(true)
    }, 800)
    return () => clearTimeout(timer)
  }, [])

  return (
    <div
      ref={mapRef}
      className={cn(
        "relative w-full h-full bg-secondary overflow-hidden",
        className
      )}
    >
      {/* Map placeholder with styled tiles */}
      <div className="absolute inset-0 bg-gradient-to-br from-secondary to-muted">
        {/* Grid pattern to simulate map */}
        <svg className="absolute inset-0 w-full h-full opacity-20" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
        
        {/* Simulated roads */}
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 400 400" preserveAspectRatio="xMidYMid slice">
          <path
            d="M 0 200 Q 100 180 200 200 T 400 200"
            stroke="rgba(249, 115, 22, 0.3)"
            strokeWidth="8"
            fill="none"
          />
          <path
            d="M 200 0 Q 180 100 200 200 T 200 400"
            stroke="rgba(249, 115, 22, 0.2)"
            strokeWidth="6"
            fill="none"
          />
          <path
            d="M 50 50 Q 150 100 200 200 T 350 350"
            stroke="rgba(249, 115, 22, 0.15)"
            strokeWidth="4"
            fill="none"
          />
        </svg>

        {/* Sample markers */}
        <div className="absolute top-1/3 left-1/4 transform -translate-x-1/2 -translate-y-1/2">
          <div className="relative">
            <div className="w-4 h-4 bg-primary rounded-full shadow-lg animate-pulse" />
            <div className="absolute -inset-2 bg-primary/20 rounded-full animate-ping" />
          </div>
        </div>
        <div className="absolute top-2/3 right-1/4 transform translate-x-1/2 -translate-y-1/2">
          <div className="w-4 h-4 bg-success rounded-full shadow-lg" />
        </div>
      </div>

      {/* Loading skeleton */}
      {!isLoaded && (
        <div className="absolute inset-0 bg-secondary skeleton" />
      )}

      {/* Map controls */}
      {showControls && isLoaded && (
        <div className="absolute right-3 top-3 flex flex-col gap-2 z-20">
          <Button
            size="icon"
            variant="secondary"
            className="h-10 w-10 rounded-xl shadow-lg glass-light dark:glass-dark"
            onClick={() => {}}
          >
            <Locate className="h-5 w-5" />
          </Button>
          <Button
            size="icon"
            variant="secondary"
            className="h-10 w-10 rounded-xl shadow-lg glass-light dark:glass-dark"
            onClick={() => {}}
          >
            <Move className="h-5 w-5" />
          </Button>
          {onToggleFullscreen && (
            <Button
              size="icon"
              variant="secondary"
              className="h-10 w-10 rounded-xl shadow-lg glass-light dark:glass-dark"
              onClick={onToggleFullscreen}
            >
              {isFullscreen ? (
                <Minimize2 className="h-5 w-5" />
              ) : (
                <Maximize2 className="h-5 w-5" />
              )}
            </Button>
          )}
        </div>
      )}

      {/* Touch hint */}
      {!isFullscreen && isLoaded && (
        <div className="absolute bottom-3 right-3 z-20">
          <span className="text-[10px] font-bold tracking-wide px-3 py-1.5 rounded-full glass-dark text-primary">
            Toque para expandir
          </span>
        </div>
      )}
    </div>
  )
}
