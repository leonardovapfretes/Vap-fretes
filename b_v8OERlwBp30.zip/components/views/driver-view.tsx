"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"
import { InteractiveMap } from "@/components/interactive-map"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import {
  Calculator,
  Map,
  Bot,
  FileText,
  Fuel,
  Target,
  TrendingUp,
  CheckCircle2,
  Circle,
  MapPin,
  MessageCircle,
  Phone,
  Share2,
  History,
  Wallet,
} from "lucide-react"

interface DriverViewProps {
  onNavigate?: (tab: string) => void
}

const deliveryStages = [
  { id: "collected", label: "Coletado", completed: true },
  { id: "transit", label: "Em Trânsito", completed: true },
  { id: "arriving", label: "Chegando", completed: false },
  { id: "delivered", label: "Entregue", completed: false },
]

export function DriverView({ onNavigate }: DriverViewProps) {
  const [monthlyGoal] = useState(5000)
  const [currentEarnings] = useState(3250)
  const [fuelSpent] = useState(480)
  const [freightsCompleted] = useState(28)
  const [hasActiveFreight] = useState(true)

  const goalProgress = (currentEarnings / monthlyGoal) * 100
  const netProfit = currentEarnings - fuelSpent

  const getGreeting = () => {
    const hour = new Date().getHours()
    if (hour < 12) return "Bom dia"
    if (hour < 18) return "Boa tarde"
    return "Boa noite"
  }

  return (
    <div className="relative h-[calc(100vh-80px)] overflow-hidden">
      {/* Fullscreen Map Background */}
      <div className="absolute inset-0">
        <InteractiveMap showControls={false} />
      </div>

      {/* Top floating header */}
      <div className="absolute top-0 left-0 right-0 z-30 p-4 pt-safe">
        <div className="flex items-center justify-between">
          <div className="glass-dark rounded-full px-4 py-2 flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-primary animate-pulse" />
            <span className="text-xs font-bold tracking-widest text-primary">
              VAPFRETES
            </span>
          </div>
          {hasActiveFreight && (
            <div className="glass-dark rounded-full px-3 py-1.5 animate-pulse cursor-pointer" onClick={() => onNavigate?.("historico")}>
              <span className="text-[10px] font-bold text-primary">
                Fretes aguardando!
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Bottom card - Driver Dashboard */}
      <div className="absolute bottom-0 left-0 right-0 z-30">
        <div className="bg-card rounded-t-[28px] shadow-2xl">
          {/* Drag handle */}
          <div className="w-10 h-1 bg-border rounded-full mx-auto mt-4 mb-3" />

          <div className="px-4 pb-6 max-h-[60vh] overflow-y-auto custom-scrollbar">
            {/* Greeting + Month selector */}
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">
                  {getGreeting()}
                </p>
                <h2 className="text-xl font-black text-foreground">
                  Motorista
                </h2>
              </div>
              <select className="bg-secondary border border-border rounded-xl px-3 py-1.5 text-xs font-medium text-muted-foreground">
                <option>Abril 2026</option>
                <option>Marco 2026</option>
              </select>
            </div>

            {/* Stats Grid 2x2 */}
            <div className="grid grid-cols-2 gap-2 mb-3">
              <div className="bg-secondary rounded-2xl p-3 relative overflow-hidden">
                <div className="absolute top-0 left-0 right-0 h-0.5 bg-primary rounded-t-2xl" />
                <p className="text-[9px] font-bold text-muted-foreground uppercase tracking-wide mb-1">
                  Lucro do mes
                </p>
                <p className="text-xl font-black text-foreground">
                  R${currentEarnings.toLocaleString("pt-BR")}
                </p>
              </div>
              <div className="bg-secondary rounded-2xl p-3 relative overflow-hidden">
                <div className="absolute top-0 left-0 right-0 h-0.5 bg-primary rounded-t-2xl" />
                <p className="text-[9px] font-bold text-muted-foreground uppercase tracking-wide mb-1">
                  Fretes feitos
                </p>
                <p className="text-xl font-black text-foreground">
                  {freightsCompleted}
                </p>
              </div>
            </div>

            {/* Monthly Goal Card */}
            <div className="bg-card border border-border rounded-2xl p-3 mb-3">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5">
                  <Target className="h-3.5 w-3.5 text-muted-foreground" />
                  <span className="text-[9px] font-bold text-muted-foreground uppercase tracking-wide">
                    Meta do mes
                  </span>
                </div>
                <button className="text-[10px] font-bold text-primary">
                  Editar
                </button>
              </div>
              <Progress value={goalProgress} className="h-2 mb-2" />
              <p className="text-xs text-muted-foreground">
                R${currentEarnings.toLocaleString("pt-BR")} de R${monthlyGoal.toLocaleString("pt-BR")} ({goalProgress.toFixed(0)}%)
              </p>
            </div>

            {/* Fuel Card */}
            <div className="bg-warning/10 border border-warning/30 rounded-2xl p-3 mb-3">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5">
                  <Fuel className="h-3.5 w-3.5 text-warning" />
                  <span className="text-[9px] font-bold text-warning uppercase tracking-wide">
                    Combustivel
                  </span>
                </div>
                <button className="text-[10px] font-bold text-primary">
                  R$/L
                </button>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-lg font-black text-warning">
                    R${fuelSpent.toLocaleString("pt-BR")}
                  </p>
                  <p className="text-[9px] text-warning/80">gasto no mes</p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-black text-foreground">
                    R${netProfit.toLocaleString("pt-BR")}
                  </p>
                  <p className="text-[9px] text-muted-foreground">lucro real</p>
                </div>
              </div>
            </div>

            {/* Active Freight Card */}
            {hasActiveFreight && (
              <div className="bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20 rounded-2xl p-3 mb-3">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-bold text-primary uppercase tracking-wide bg-primary/10 px-2 py-0.5 rounded-full">
                    Em andamento
                  </span>
                  <span className="text-lg font-black text-foreground">R$180</span>
                </div>
                
                <p className="text-xs text-muted-foreground mb-3">
                  Rua das Flores, 100 → Av. Brasil, 500
                </p>

                {/* Delivery stages */}
                <div className="flex items-center justify-between mb-3">
                  {deliveryStages.map((stage, index) => (
                    <div key={stage.id} className="flex flex-col items-center">
                      <div className={cn(
                        "w-6 h-6 rounded-full flex items-center justify-center mb-1",
                        stage.completed ? "bg-primary" : "bg-secondary"
                      )}>
                        {stage.completed ? (
                          <CheckCircle2 className="h-4 w-4 text-primary-foreground" />
                        ) : (
                          <Circle className="h-4 w-4 text-muted-foreground" />
                        )}
                      </div>
                      <span className={cn(
                        "text-[8px] font-medium",
                        stage.completed ? "text-primary" : "text-muted-foreground"
                      )}>
                        {stage.label}
                      </span>
                    </div>
                  ))}
                </div>

                <Progress value={50} className="h-1 mb-3" />
                
                <div className="flex gap-2">
                  <Button
                    className="flex-1 h-10 rounded-xl font-bold text-xs"
                    onClick={() => onNavigate?.("mapa")}
                  >
                    Ver no mapa
                  </Button>
                  <Button
                    variant="secondary"
                    className="flex-1 h-10 rounded-xl font-semibold text-xs"
                  >
                    Finalizar
                  </Button>
                </div>

                <Button
                  variant="outline"
                  className="w-full mt-2 h-10 rounded-xl text-xs font-bold border-success/50 text-success hover:bg-success/10"
                >
                  <Share2 className="h-4 w-4 mr-2" />
                  Compartilhar localizacao
                </Button>
              </div>
            )}

            {/* Quick actions */}
            <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4 snap-carousel mb-3">
              {[
                { icon: Calculator, label: "Calcular", tab: "calcular" },
                { icon: Map, label: "Mapa", tab: "mapa" },
                { icon: Bot, label: "Agente", tab: "agente" },
                { icon: FileText, label: "Relatorio", tab: "relatorio" },
              ].map(({ icon: Icon, label, tab }) => (
                <button
                  key={tab}
                  onClick={() => onNavigate?.(tab)}
                  className="flex-shrink-0 flex flex-col items-center gap-1 p-3 rounded-2xl border border-border bg-card hover:bg-secondary transition-colors min-w-[72px]"
                >
                  <Icon className="h-5 w-5 text-foreground" />
                  <span className="text-[10px] font-bold text-foreground">{label}</span>
                </button>
              ))}
            </div>

            {/* Tip */}
            <div className="bg-secondary rounded-xl p-3 mb-3">
              <p className="text-xs text-muted-foreground">
                Calcule um orcamento para seu proximo frete!
              </p>
            </div>

            {/* Main actions */}
            <div className="flex gap-2">
              <Button
                className="flex-1 h-12 rounded-2xl font-bold"
                onClick={() => onNavigate?.("historico")}
              >
                <History className="h-4 w-4 mr-2" />
                Historico
              </Button>
              <Button
                variant="secondary"
                className="flex-1 h-12 rounded-2xl font-semibold"
                onClick={() => onNavigate?.("financeiro")}
              >
                <Wallet className="h-4 w-4 mr-2" />
                Financeiro
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
