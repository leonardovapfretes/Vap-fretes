"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"
import { InteractiveMap } from "@/components/interactive-map"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  TrendingUp,
  TrendingDown,
  Users,
  Truck,
  DollarSign,
  MapPin,
  History,
  BarChart3,
  Map,
  ChevronRight,
  Clock,
  CheckCircle2,
  AlertCircle,
} from "lucide-react"
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
} from "recharts"

interface ManagerViewProps {
  onNavigate?: (tab: string) => void
}

const mockKPIs = {
  revenue: 45680,
  revenueChange: 12.5,
  vapProfit: 4568,
  totalFreights: 156,
  activeFreights: 8,
  drivers: 12,
  activeDrivers: 8,
}

const mockChartData = [
  { name: "Seg", fretes: 18, valor: 3200 },
  { name: "Ter", fretes: 22, valor: 4100 },
  { name: "Qua", fretes: 15, valor: 2800 },
  { name: "Qui", fretes: 28, valor: 5200 },
  { name: "Sex", fretes: 32, valor: 6100 },
  { name: "Sab", fretes: 25, valor: 4800 },
  { name: "Dom", fretes: 16, valor: 3100 },
]

const mockDrivers = [
  { id: "1", name: "Joao Silva", status: "active", freights: 28, earnings: 4200 },
  { id: "2", name: "Pedro Santos", status: "active", freights: 22, earnings: 3800 },
  { id: "3", name: "Carlos Lima", status: "offline", freights: 18, earnings: 2900 },
  { id: "4", name: "Ana Costa", status: "active", freights: 25, earnings: 4100 },
]

export function ManagerView({ onNavigate }: ManagerViewProps) {
  const [isMapModalOpen, setIsMapModalOpen] = useState(false)

  return (
    <div className="relative h-[calc(100vh-80px)] overflow-hidden">
      {/* Fullscreen Map Background */}
      <div className="absolute inset-0">
        <InteractiveMap showControls={false} />
      </div>

      {/* Top floating header */}
      <div className="absolute top-0 left-0 right-0 z-30 p-4 pt-safe">
        <div className="flex items-center justify-between">
          <div className="glass-dark rounded-full px-4 py-2 flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-primary animate-pulse" />
            <span className="text-xs font-bold tracking-widest text-primary">
              VAPFRETES
            </span>
          </div>
          <div className="glass-dark rounded-full px-3 py-1.5 border border-primary/30">
            <span className="text-[10px] font-bold text-primary">
              Gerente
            </span>
          </div>
        </div>
      </div>

      {/* Bottom Dashboard Card */}
      <div className="absolute bottom-0 left-0 right-0 z-30">
        <div className="bg-card rounded-t-[28px] shadow-2xl">
          {/* Drag handle */}
          <div className="w-10 h-1 bg-border rounded-full mx-auto mt-4 mb-3" />

          <div className="px-4 pb-6 max-h-[65vh] overflow-y-auto custom-scrollbar">
            {/* Header with month selector */}
            <div className="flex items-center gap-2 mb-4">
              <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">
                Painel Gerente
              </span>
              <span className="text-muted-foreground">·</span>
              <select className="bg-transparent border-none text-[10px] font-bold text-muted-foreground uppercase tracking-wide p-0 focus:outline-none">
                <option>Abril 2026</option>
                <option>Marco 2026</option>
              </select>
            </div>

            {/* KPI Grid */}
            <div className="grid grid-cols-2 gap-2 mb-4">
              <div className="bg-secondary rounded-2xl p-3 text-center">
                <p className="text-xl font-black text-foreground">
                  R${mockKPIs.vapProfit.toLocaleString("pt-BR")}
                </p>
                <p className="text-[9px] font-semibold text-muted-foreground uppercase tracking-wide">
                  Lucro VapFretes
                </p>
              </div>
              <div className="bg-secondary rounded-2xl p-3 text-center">
                <p className="text-xl font-black text-foreground">
                  R${mockKPIs.revenue.toLocaleString("pt-BR")}
                </p>
                <p className="text-[9px] font-semibold text-muted-foreground uppercase tracking-wide">
                  Faturamento
                </p>
              </div>
              <div className="bg-secondary rounded-2xl p-3 text-center">
                <p className="text-xl font-black text-foreground">
                  {mockKPIs.totalFreights}
                </p>
                <p className="text-[9px] font-semibold text-muted-foreground uppercase tracking-wide">
                  Fretes
                </p>
              </div>
              <button 
                className="bg-secondary rounded-2xl p-3 text-center hover:bg-secondary/80 transition-colors"
                onClick={() => setIsMapModalOpen(true)}
              >
                <p className="text-xl font-black text-primary">
                  {mockKPIs.activeFreights}
                </p>
                <p className="text-[9px] font-semibold text-primary uppercase tracking-wide">
                  Em andamento &rsaquo;
                </p>
              </button>
            </div>

            {/* Performance Chart */}
            <div className="bg-secondary/50 rounded-2xl p-4 mb-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-xs font-bold text-foreground">
                  Performance Semanal
                </h3>
                <div className="flex items-center gap-1 text-success">
                  <TrendingUp className="h-3 w-3" />
                  <span className="text-[10px] font-bold">+{mockKPIs.revenueChange}%</span>
                </div>
              </div>
              <div className="h-32">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={mockChartData}>
                    <defs>
                      <linearGradient id="colorValor" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#f97316" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#f97316" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <XAxis 
                      dataKey="name" 
                      axisLine={false} 
                      tickLine={false}
                      tick={{ fontSize: 10, fill: '#707070' }}
                    />
                    <Tooltip
                      contentStyle={{
                        background: 'rgba(30, 32, 35, 0.95)',
                        border: '1px solid rgba(249, 115, 22, 0.3)',
                        borderRadius: '12px',
                        fontSize: '12px',
                      }}
                      formatter={(value: number) => [`R$${value}`, 'Valor']}
                    />
                    <Area
                      type="monotone"
                      dataKey="valor"
                      stroke="#f97316"
                      strokeWidth={2}
                      fill="url(#colorValor)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Drivers Preview */}
            <div className="mb-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-xs font-bold text-foreground">
                  Equipe ({mockDrivers.length})
                </h3>
                <button 
                  className="text-[10px] font-bold text-primary"
                  onClick={() => onNavigate?.("equipe")}
                >
                  Ver todos
                </button>
              </div>
              <div className="space-y-2">
                {mockDrivers.slice(0, 3).map((driver) => (
                  <div 
                    key={driver.id}
                    className="flex items-center justify-between p-3 bg-secondary/50 rounded-xl"
                  >
                    <div className="flex items-center gap-3">
                      <div className={cn(
                        "w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold",
                        driver.status === "active" ? "bg-success/20 text-success" : "bg-muted text-muted-foreground"
                      )}>
                        {driver.name.charAt(0)}
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-foreground">
                          {driver.name}
                        </p>
                        <p className="text-[10px] text-muted-foreground">
                          {driver.freights} fretes · R${driver.earnings.toLocaleString("pt-BR")}
                        </p>
                      </div>
                    </div>
                    <div className={cn(
                      "w-2 h-2 rounded-full",
                      driver.status === "active" ? "bg-success" : "bg-muted-foreground"
                    )} />
                  </div>
                ))}
              </div>
            </div>

            {/* Main actions */}
            <div className="flex gap-2">
              <Button
                className="flex-1 h-12 rounded-2xl font-bold"
                onClick={() => onNavigate?.("historico")}
              >
                <History className="h-4 w-4 mr-2" />
                Fretes
              </Button>
              <Button
                variant="secondary"
                className="flex-1 h-12 rounded-2xl font-semibold"
                onClick={() => onNavigate?.("equipe")}
              >
                <Users className="h-4 w-4 mr-2" />
                Equipe
              </Button>
              <Button
                variant="secondary"
                size="icon"
                className="h-12 w-12 rounded-2xl"
                onClick={() => setIsMapModalOpen(true)}
              >
                <Map className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Map Modal */}
      <Dialog open={isMapModalOpen} onOpenChange={setIsMapModalOpen}>
        <DialogContent className="max-w-lg p-0 overflow-hidden">
          <DialogHeader className="p-4 pb-0">
            <DialogTitle>Rastrear Motoristas</DialogTitle>
          </DialogHeader>
          <div className="h-[400px] m-4 mt-2 rounded-2xl overflow-hidden">
            <InteractiveMap showControls={true} />
          </div>
          <div className="p-4 pt-0 space-y-2">
            {mockDrivers.filter(d => d.status === "active").map((driver) => (
              <div 
                key={driver.id}
                className="flex items-center justify-between p-3 bg-secondary rounded-xl"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-success/20 flex items-center justify-center text-sm font-bold text-success">
                    {driver.name.charAt(0)}
                  </div>
                  <div>
                    <p className="text-sm font-semibold">{driver.name}</p>
                    <p className="text-[10px] text-muted-foreground">
                      Em rota · Frete ativo
                    </p>
                  </div>
                </div>
                <Button size="sm" variant="ghost" className="text-primary">
                  <MapPin className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
