"use client"

import { useState, useRef, useEffect } from "react"
import { cn } from "@/lib/utils"
import { InteractiveMap } from "@/components/interactive-map"
import { FloatingSearch } from "@/components/floating-search"
import { FreightCard } from "@/components/freight-card"
import { Button } from "@/components/ui/button"
import { Plus, ChevronUp, ChevronDown, History, Truck, Package, X, MapPin, Navigation } from "lucide-react"

const mockActiveFreights = [
  {
    id: "1",
    origin: "Rua das Flores, 100 - Jacarei",
    destination: "Av. Brasil, 500 - SJC",
    value: 150,
    status: "in_transit" as const,
    date: "Hoje, 14:30",
    driverName: "Joao Silva",
    distance: 15,
    estimatedTime: "25 min",
  },
]

const mockHistoryFreights = [
  {
    id: "2",
    origin: "Centro, Jacarei",
    destination: "Jardim Satelite, SJC",
    value: 180,
    status: "delivered" as const,
    date: "Ontem",
  },
  {
    id: "3",
    origin: "Vila Industrial",
    destination: "Urbanova, SJC",
    value: 220,
    status: "delivered" as const,
    date: "02/04/2026",
  },
]

type SheetState = "collapsed" | "partial" | "expanded"

interface ClientViewProps {
  onNavigate?: (tab: string) => void
}

export function ClientView({ onNavigate }: ClientViewProps) {
  const [sheetState, setSheetState] = useState<SheetState>("collapsed")
  const [showSearch, setShowSearch] = useState(false)
  const [isDragging, setIsDragging] = useState(false)
  const [startY, setStartY] = useState(0)
  const [currentY, setCurrentY] = useState(0)
  const sheetRef = useRef<HTMLDivElement>(null)

  // Sheet heights based on state
  const getSheetHeight = () => {
    switch (sheetState) {
      case "collapsed":
        return "h-[100px]"
      case "partial":
        return "h-[45%]"
      case "expanded":
        return "h-[85%]"
      default:
        return "h-[100px]"
    }
  }

  // Handle touch/mouse start
  const handleDragStart = (e: React.TouchEvent | React.MouseEvent) => {
    setIsDragging(true)
    const clientY = "touches" in e ? e.touches[0].clientY : e.clientY
    setStartY(clientY)
    setCurrentY(clientY)
  }

  // Handle touch/mouse move
  const handleDragMove = (e: React.TouchEvent | React.MouseEvent) => {
    if (!isDragging) return
    const clientY = "touches" in e ? e.touches[0].clientY : e.clientY
    setCurrentY(clientY)
  }

  // Handle touch/mouse end
  const handleDragEnd = () => {
    if (!isDragging) return
    setIsDragging(false)
    
    const diff = startY - currentY
    const threshold = 50

    if (diff > threshold) {
      // Swiped up
      if (sheetState === "collapsed") setSheetState("partial")
      else if (sheetState === "partial") setSheetState("expanded")
    } else if (diff < -threshold) {
      // Swiped down
      if (sheetState === "expanded") setSheetState("partial")
      else if (sheetState === "partial") setSheetState("collapsed")
    }
  }

  // Toggle sheet state on handle click
  const toggleSheet = () => {
    if (sheetState === "collapsed") setSheetState("partial")
    else if (sheetState === "partial") setSheetState("expanded")
    else setSheetState("collapsed")
  }

  return (
    <div className="relative h-[calc(100vh-80px)] overflow-hidden bg-background">
      {/* Fullscreen Map - Always visible and clean */}
      <div className="absolute inset-0">
        <InteractiveMap
          showControls={true}
          isFullscreen={false}
          onToggleFullscreen={() => {}}
        />
      </div>

      {/* Top floating elements - Minimal */}
      <div className="absolute top-4 left-4 right-4 z-20 flex items-center justify-between pointer-events-none">
        {/* Logo badge */}
        <div className="glass-dark rounded-full px-4 py-2 flex items-center gap-2 pointer-events-auto">
          <div className="w-2.5 h-2.5 rounded-full bg-primary animate-pulse" />
          <span className="text-[10px] font-bold tracking-widest text-primary uppercase">
            VapFretes
          </span>
        </div>

        {/* Search trigger button */}
        <button
          onClick={() => setShowSearch(true)}
          className="glass-dark rounded-full px-4 py-2 flex items-center gap-2 pointer-events-auto hover:bg-white/10 transition-colors"
        >
          <MapPin className="h-4 w-4 text-primary" />
          <span className="text-xs text-foreground">Para onde?</span>
        </button>
      </div>

      {/* Floating Action Button - New freight */}
      <button
        onClick={() => onNavigate?.("calcular")}
        className="absolute right-4 bottom-[120px] z-20 w-14 h-14 rounded-full bg-primary text-primary-foreground shadow-lg shadow-primary/30 flex items-center justify-center hover:scale-105 active:scale-95 transition-transform"
      >
        <Plus className="h-6 w-6" />
      </button>

      {/* Map controls - Recenter */}
      <div className="absolute left-4 bottom-[120px] z-20 flex flex-col gap-2">
        <button className="w-10 h-10 rounded-full glass-dark flex items-center justify-center hover:bg-white/10 transition-colors">
          <Navigation className="h-4 w-4 text-foreground" />
        </button>
      </div>

      {/* Bottom Sheet - Draggable */}
      <div
        ref={sheetRef}
        className={cn(
          "absolute bottom-0 left-0 right-0 z-30 transition-all duration-300 ease-out",
          getSheetHeight(),
          isDragging && "transition-none"
        )}
        style={isDragging ? { 
          height: `calc(100px + ${Math.max(0, startY - currentY)}px)`,
          maxHeight: "85%"
        } : undefined}
      >
        <div className="h-full glass-light dark:glass-dark rounded-t-3xl flex flex-col overflow-hidden border-t border-white/10">
          {/* Drag handle area */}
          <div
            className="flex-shrink-0 pt-3 pb-2 px-4 cursor-grab active:cursor-grabbing touch-none"
            onTouchStart={handleDragStart}
            onTouchMove={handleDragMove}
            onTouchEnd={handleDragEnd}
            onMouseDown={handleDragStart}
            onMouseMove={handleDragMove}
            onMouseUp={handleDragEnd}
            onMouseLeave={handleDragEnd}
            onClick={toggleSheet}
          >
            <div className="w-10 h-1 bg-border/60 rounded-full mx-auto" />
            
            {/* Collapsed state preview */}
            {sheetState === "collapsed" && (
              <div className="flex items-center justify-between mt-3">
                <div className="flex items-center gap-3">
                  {mockActiveFreights.length > 0 && (
                    <div className="flex items-center gap-2 bg-primary/10 rounded-full px-3 py-1.5">
                      <Truck className="h-4 w-4 text-primary" />
                      <span className="text-xs font-bold text-primary">
                        {mockActiveFreights.length} ativo
                      </span>
                    </div>
                  )}
                  <span className="text-xs text-muted-foreground">
                    Arraste para ver mais
                  </span>
                </div>
                <ChevronUp className="h-5 w-5 text-muted-foreground" />
              </div>
            )}
          </div>

          {/* Sheet content - Only visible when not collapsed */}
          {sheetState !== "collapsed" && (
            <div className="flex-1 overflow-y-auto px-4 pb-4 custom-scrollbar">
              {/* Quick actions */}
              <div className="flex items-center gap-3 mb-4">
                <Button 
                  className="flex-1 h-12 rounded-xl font-bold text-sm gap-2"
                  onClick={() => onNavigate?.("calcular")}
                >
                  <Plus className="h-4 w-4" />
                  Solicitar Frete
                </Button>
                <Button
                  variant="secondary"
                  size="icon"
                  className="h-12 w-12 rounded-xl"
                  onClick={() => onNavigate?.("historico")}
                >
                  <History className="h-5 w-5" />
                </Button>
              </div>

              {/* Active freights section */}
              {mockActiveFreights.length > 0 && (
                <div className="mb-4">
                  <h3 className="text-sm font-bold text-foreground mb-3 flex items-center gap-2">
                    <Truck className="h-4 w-4 text-primary" />
                    Fretes Ativos
                  </h3>
                  <div className="space-y-3">
                    {mockActiveFreights.map((freight) => (
                      <div 
                        key={freight.id}
                        className="p-4 rounded-2xl bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20"
                      >
                        <div className="flex items-center justify-between mb-3">
                          <span className="px-2 py-1 rounded-full bg-primary/20 text-primary text-[10px] font-bold uppercase">
                            Em transito
                          </span>
                          <span className="text-lg font-black text-foreground">
                            R${freight.value}
                          </span>
                        </div>
                        
                        <div className="space-y-2">
                          <div className="flex items-center gap-2 text-sm">
                            <div className="w-2 h-2 rounded-full bg-primary flex-shrink-0" />
                            <span className="text-muted-foreground truncate">
                              {freight.origin}
                            </span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <div className="w-2 h-2 rounded-full bg-success flex-shrink-0" />
                            <span className="text-muted-foreground truncate">
                              {freight.destination}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center justify-between mt-3 pt-3 border-t border-border/30">
                          <div className="flex items-center gap-2">
                            <div className="w-6 h-6 rounded-full bg-secondary flex items-center justify-center">
                              <span className="text-[10px] font-bold">JS</span>
                            </div>
                            <span className="text-xs text-muted-foreground">
                              {freight.driverName}
                            </span>
                          </div>
                          <span className="text-xs font-medium text-primary">
                            {freight.estimatedTime} restantes
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* History section - Only in expanded state */}
              {sheetState === "expanded" && (
                <div>
                  <h3 className="text-sm font-bold text-foreground mb-3 flex items-center gap-2">
                    <History className="h-4 w-4 text-muted-foreground" />
                    Historico Recente
                  </h3>
                  <div className="space-y-3">
                    {mockHistoryFreights.map((freight) => (
                      <FreightCard
                        key={freight.id}
                        {...freight}
                        variant="compact"
                        onAction={() => onNavigate?.("historico")}
                      />
                    ))}
                    
                    {/* View all button */}
                    <button 
                      className="w-full py-3 rounded-xl border border-dashed border-border/50 flex items-center justify-center gap-2 text-muted-foreground hover:text-foreground hover:border-primary/50 transition-colors"
                      onClick={() => onNavigate?.("historico")}
                    >
                      <Package className="h-4 w-4" />
                      <span className="text-sm font-medium">Ver todo historico</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Collapse hint in partial state */}
              {sheetState === "partial" && (
                <button 
                  onClick={() => setSheetState("expanded")}
                  className="w-full py-3 flex items-center justify-center gap-2 text-muted-foreground"
                >
                  <ChevronUp className="h-4 w-4" />
                  <span className="text-xs">Arraste para ver historico</span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Search overlay modal */}
      {showSearch && (
        <div className="absolute inset-0 z-50 bg-background/95 backdrop-blur-sm">
          <div className="p-4 pt-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold">Nova Rota</h2>
              <button
                onClick={() => setShowSearch(false)}
                className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <FloatingSearch />
            
            {/* Recent searches */}
            <div className="mt-6">
              <h3 className="text-sm font-medium text-muted-foreground mb-3">Buscas recentes</h3>
              <div className="space-y-2">
                {[
                  "Av. Brasil, 500 - Sao Jose dos Campos",
                  "Rua das Flores, 100 - Jacarei",
                  "Centro, Jacarei"
                ].map((address, i) => (
                  <button 
                    key={i}
                    className="w-full p-3 rounded-xl bg-secondary/50 text-left flex items-center gap-3 hover:bg-secondary transition-colors"
                  >
                    <History className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                    <span className="text-sm text-foreground truncate">{address}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
