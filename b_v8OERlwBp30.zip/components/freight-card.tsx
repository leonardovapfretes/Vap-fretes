"use client"

import { cn } from "@/lib/utils"
import { MapPin, Clock, Truck, ChevronRight, Phone } from "lucide-react"
import { Button } from "@/components/ui/button"

export type FreightStatus = "pending" | "active" | "in_transit" | "delivered" | "cancelled"

interface FreightCardProps {
  id: string
  origin: string
  destination: string
  value: number
  status: FreightStatus
  date: string
  customerName?: string
  driverName?: string
  distance?: number
  estimatedTime?: string
  className?: string
  variant?: "compact" | "detailed"
  onAction?: () => void
  onCall?: () => void
}

const statusConfig: Record<FreightStatus, { label: string; color: string; bgColor: string }> = {
  pending: { label: "Pendente", color: "text-warning", bgColor: "bg-warning/10" },
  active: { label: "Em andamento", color: "text-primary", bgColor: "bg-primary/10" },
  in_transit: { label: "Em trânsito", color: "text-chart-2", bgColor: "bg-chart-2/10" },
  delivered: { label: "Entregue", color: "text-success", bgColor: "bg-success/10" },
  cancelled: { label: "Cancelado", color: "text-destructive", bgColor: "bg-destructive/10" },
}

export function FreightCard({
  id,
  origin,
  destination,
  value,
  status,
  date,
  customerName,
  driverName,
  distance,
  estimatedTime,
  className,
  variant = "compact",
  onAction,
  onCall,
}: FreightCardProps) {
  const { label, color, bgColor } = statusConfig[status]

  if (variant === "compact") {
    return (
      <div
        className={cn(
          "p-4 rounded-2xl bg-card border border-border/50 hover:border-primary/30 transition-all duration-200 cursor-pointer group",
          className
        )}
        onClick={onAction}
      >
        <div className="flex items-start justify-between mb-3">
          <div className={cn("px-2.5 py-1 rounded-full text-[10px] font-bold tracking-wide uppercase", bgColor, color)}>
            {label}
          </div>
          <span className="text-lg font-black text-foreground">
            R${value.toLocaleString("pt-BR")}
          </span>
        </div>

        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-primary flex-shrink-0" />
            <span className="text-sm text-foreground truncate">{origin}</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="w-3.5 h-3.5 text-success flex-shrink-0" />
            <span className="text-sm text-muted-foreground truncate">{destination}</span>
          </div>
        </div>

        <div className="flex items-center justify-between mt-3 pt-3 border-t border-border/50">
          <span className="text-xs text-muted-foreground">{date}</span>
          <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
        </div>
      </div>
    )
  }

  return (
    <div className={cn("p-5 rounded-2xl bg-card border border-border/50", className)}>
      <div className="flex items-start justify-between mb-4">
        <div>
          <div className={cn("inline-flex px-2.5 py-1 rounded-full text-[10px] font-bold tracking-wide uppercase mb-2", bgColor, color)}>
            {label}
          </div>
          <h3 className="text-2xl font-black text-foreground">
            R${value.toLocaleString("pt-BR")}
          </h3>
        </div>
        <span className="text-xs text-muted-foreground">{date}</span>
      </div>

      <div className="space-y-3 mb-4">
        <div className="flex items-start gap-3">
          <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
            <div className="w-2 h-2 rounded-full bg-primary" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-0.5">Origem</p>
            <p className="text-sm font-medium text-foreground">{origin}</p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <div className="w-6 h-6 rounded-full bg-success/20 flex items-center justify-center flex-shrink-0 mt-0.5">
            <MapPin className="w-3 h-3 text-success" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-0.5">Destino</p>
            <p className="text-sm font-medium text-foreground">{destination}</p>
          </div>
        </div>
      </div>

      {(distance || estimatedTime) && (
        <div className="flex items-center gap-4 py-3 px-4 rounded-xl bg-secondary/50 mb-4">
          {distance && (
            <div className="flex items-center gap-2">
              <Truck className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm font-medium">{distance} km</span>
            </div>
          )}
          {estimatedTime && (
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm font-medium">{estimatedTime}</span>
            </div>
          )}
        </div>
      )}

      {(customerName || driverName) && (
        <div className="flex items-center justify-between py-3 border-t border-border/50">
          <div>
            <p className="text-xs text-muted-foreground">
              {customerName ? "Cliente" : "Motorista"}
            </p>
            <p className="text-sm font-semibold">{customerName || driverName}</p>
          </div>
          {onCall && (
            <Button
              size="icon"
              variant="outline"
              className="h-10 w-10 rounded-xl"
              onClick={(e) => {
                e.stopPropagation()
                onCall()
              }}
            >
              <Phone className="h-4 w-4" />
            </Button>
          )}
        </div>
      )}

      {onAction && (
        <Button
          className="w-full mt-3 h-12 rounded-xl font-bold"
          onClick={onAction}
        >
          Ver detalhes
        </Button>
      )}
    </div>
  )
}
