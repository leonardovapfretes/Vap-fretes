"use client"

import { cn } from "@/lib/utils"
import { 
  Home, 
  Calculator, 
  Map, 
  History, 
  User,
  BarChart3,
  Users,
  Truck
} from "lucide-react"
import { useProfile, ProfileType } from "@/contexts/profile-context"

interface NavItem {
  id: string
  label: string
  icon: React.ReactNode
  profiles: ProfileType[]
}

const navItems: NavItem[] = [
  {
    id: "dashboard",
    label: "Início",
    icon: <Home className="h-5 w-5" />,
    profiles: ["cliente", "motorista", "gerente"],
  },
  {
    id: "calcular",
    label: "Calcular",
    icon: <Calculator className="h-5 w-5" />,
    profiles: ["cliente", "motorista", "gerente"],
  },
  {
    id: "mapa",
    label: "Mapa",
    icon: <Map className="h-5 w-5" />,
    profiles: ["cliente", "motorista", "gerente"],
  },
  {
    id: "historico",
    label: "Histórico",
    icon: <History className="h-5 w-5" />,
    profiles: ["cliente", "motorista", "gerente"],
  },
  {
    id: "financeiro",
    label: "Financeiro",
    icon: <BarChart3 className="h-5 w-5" />,
    profiles: ["motorista"],
  },
  {
    id: "equipe",
    label: "Equipe",
    icon: <Users className="h-5 w-5" />,
    profiles: ["gerente"],
  },
  {
    id: "perfil",
    label: "Perfil",
    icon: <User className="h-5 w-5" />,
    profiles: ["cliente", "motorista", "gerente"],
  },
]

interface BottomNavigationProps {
  activeTab: string
  onTabChange: (tab: string) => void
}

export function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  const { profile } = useProfile()

  const filteredItems = navItems.filter((item) => 
    item.profiles.includes(profile)
  ).slice(0, 5)

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 glass-dark border-t border-border/50 safe-area-pb">
      <div className="flex items-center justify-around px-2 py-2">
        {filteredItems.map((item) => {
          const isActive = activeTab === item.id
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={cn(
                "flex flex-col items-center gap-1 px-3 py-2 rounded-xl transition-all duration-200 min-w-[64px]",
                isActive
                  ? "text-primary bg-primary/10"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
              )}
            >
              <span className={cn(
                "transition-transform duration-200",
                isActive && "scale-110"
              )}>
                {item.icon}
              </span>
              <span className={cn(
                "text-[10px] font-semibold tracking-wide",
                isActive && "text-primary"
              )}>
                {item.label}
              </span>
            </button>
          )
        })}
      </div>
    </nav>
  )
}
