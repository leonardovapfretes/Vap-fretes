"use client"

import { useState, useRef, useEffect } from "react"
import { cn } from "@/lib/utils"
import { MapPin, Search, X, Navigation } from "lucide-react"
import { Input } from "@/components/ui/input"

interface SearchSuggestion {
  id: string
  title: string
  subtitle: string
  type: "recent" | "suggestion"
}

const mockSuggestions: SearchSuggestion[] = [
  { id: "1", title: "Rua das Flores, 100", subtitle: "Jacareí, SP", type: "recent" },
  { id: "2", title: "Av. Brasil, 500", subtitle: "São José dos Campos, SP", type: "recent" },
  { id: "3", title: "Shopping Center Vale", subtitle: "São José dos Campos, SP", type: "suggestion" },
]

interface FloatingSearchProps {
  className?: string
  onOriginChange?: (value: string) => void
  onDestinationChange?: (value: string) => void
}

export function FloatingSearch({ className, onOriginChange, onDestinationChange }: FloatingSearchProps) {
  const [origin, setOrigin] = useState("")
  const [destination, setDestination] = useState("")
  const [activeField, setActiveField] = useState<"origin" | "destination" | null>(null)
  const [suggestions, setSuggestions] = useState<SearchSuggestion[]>([])
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (activeField) {
      setSuggestions(mockSuggestions)
    } else {
      setSuggestions([])
    }
  }, [activeField])

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setActiveField(null)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  const handleSelectSuggestion = (suggestion: SearchSuggestion) => {
    const value = `${suggestion.title}, ${suggestion.subtitle}`
    if (activeField === "origin") {
      setOrigin(value)
      onOriginChange?.(value)
    } else if (activeField === "destination") {
      setDestination(value)
      onDestinationChange?.(value)
    }
    setActiveField(null)
  }

  return (
    <div ref={containerRef} className={cn("w-full", className)}>
      <div className="glass-dark rounded-2xl p-3 shadow-2xl">
        {/* Origin field */}
        <div className="relative flex items-center gap-3 mb-2">
          <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
            <div className="w-3 h-3 rounded-full bg-primary" />
          </div>
          <div className="flex-1 relative">
            <Input
              value={origin}
              onChange={(e) => {
                setOrigin(e.target.value)
                onOriginChange?.(e.target.value)
              }}
              onFocus={() => setActiveField("origin")}
              placeholder="De onde sai o frete?"
              className="bg-secondary/50 border-0 h-11 pl-3 pr-10 rounded-xl text-sm placeholder:text-muted-foreground/70 focus-visible:ring-1 focus-visible:ring-primary"
            />
            {origin && (
              <button
                onClick={() => {
                  setOrigin("")
                  onOriginChange?.("")
                }}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>

        {/* Connector line */}
        <div className="flex items-center gap-3 pl-4 -my-1">
          <div className="w-0.5 h-4 bg-border rounded-full" />
        </div>

        {/* Destination field */}
        <div className="relative flex items-center gap-3 mt-2">
          <div className="flex-shrink-0 w-8 h-8 rounded-full bg-success/20 flex items-center justify-center">
            <MapPin className="w-4 h-4 text-success" />
          </div>
          <div className="flex-1 relative">
            <Input
              value={destination}
              onChange={(e) => {
                setDestination(e.target.value)
                onDestinationChange?.(e.target.value)
              }}
              onFocus={() => setActiveField("destination")}
              placeholder="Para onde vai?"
              className="bg-secondary/50 border-0 h-11 pl-3 pr-10 rounded-xl text-sm placeholder:text-muted-foreground/70 focus-visible:ring-1 focus-visible:ring-primary"
            />
            {destination && (
              <button
                onClick={() => {
                  setDestination("")
                  onDestinationChange?.("")
                }}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>

        {/* Use current location button */}
        <button className="mt-3 w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-primary/10 text-primary text-sm font-semibold hover:bg-primary/20 transition-colors">
          <Navigation className="h-4 w-4" />
          Usar minha localização
        </button>
      </div>

      {/* Suggestions dropdown */}
      {activeField && suggestions.length > 0 && (
        <div className="mt-2 glass-dark rounded-2xl p-2 shadow-2xl">
          {suggestions.map((suggestion) => (
            <button
              key={suggestion.id}
              onClick={() => handleSelectSuggestion(suggestion)}
              className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-secondary/50 transition-colors text-left"
            >
              <div className="flex-shrink-0 w-10 h-10 rounded-xl bg-secondary flex items-center justify-center">
                {suggestion.type === "recent" ? (
                  <Search className="w-4 h-4 text-muted-foreground" />
                ) : (
                  <MapPin className="w-4 h-4 text-primary" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground truncate">
                  {suggestion.title}
                </p>
                <p className="text-xs text-muted-foreground truncate">
                  {suggestion.subtitle}
                </p>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
