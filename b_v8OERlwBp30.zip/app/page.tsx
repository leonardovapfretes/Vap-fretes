"use client"

import { useState } from "react"
import { ProfileProvider, useProfile, ProfileType } from "@/contexts/profile-context"
import { BottomNavigation } from "@/components/bottom-navigation"
import { ClientView } from "@/components/views/client-view"
import { DriverView } from "@/components/views/driver-view"
import { ManagerView } from "@/components/views/manager-view"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { cn } from "@/lib/utils"

function AppContent() {
  const { profile, setProfile } = useProfile()
  const [activeTab, setActiveTab] = useState("dashboard")

  const handleNavigate = (tab: string) => {
    setActiveTab(tab)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Profile Switcher - Demo purposes */}
      <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50">
        <Tabs value={profile} onValueChange={(v) => setProfile(v as ProfileType)}>
          <TabsList className="glass-dark rounded-full p-1">
            <TabsTrigger 
              value="cliente" 
              className="rounded-full px-3 py-1.5 text-[10px] font-bold data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              Cliente
            </TabsTrigger>
            <TabsTrigger 
              value="motorista"
              className="rounded-full px-3 py-1.5 text-[10px] font-bold data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              Motorista
            </TabsTrigger>
            <TabsTrigger 
              value="gerente"
              className="rounded-full px-3 py-1.5 text-[10px] font-bold data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              Gerente
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Main Content */}
      <main className="pb-20">
        {activeTab === "dashboard" && (
          <>
            {profile === "cliente" && <ClientView onNavigate={handleNavigate} />}
            {profile === "motorista" && <DriverView onNavigate={handleNavigate} />}
            {profile === "gerente" && <ManagerView onNavigate={handleNavigate} />}
          </>
        )}

        {activeTab === "calcular" && (
          <CalculatorView onBack={() => setActiveTab("dashboard")} />
        )}

        {activeTab === "mapa" && (
          <MapFullView onBack={() => setActiveTab("dashboard")} />
        )}

        {activeTab === "historico" && (
          <HistoryView onBack={() => setActiveTab("dashboard")} />
        )}

        {activeTab === "financeiro" && (
          <FinanceView onBack={() => setActiveTab("dashboard")} />
        )}

        {activeTab === "equipe" && (
          <TeamView onBack={() => setActiveTab("dashboard")} />
        )}

        {activeTab === "perfil" && (
          <ProfileSettingsView onBack={() => setActiveTab("dashboard")} />
        )}
      </main>

      {/* Bottom Navigation */}
      <BottomNavigation activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  )
}

// Placeholder views
function CalculatorView({ onBack }: { onBack: () => void }) {
  return (
    <div className="min-h-screen p-4 pt-20">
      <div className="max-w-md mx-auto">
        <button onClick={onBack} className="text-sm text-primary mb-4">
          ← Voltar
        </button>
        <h1 className="text-2xl font-black mb-6">Calcular Frete</h1>
        
        <div className="space-y-4">
          <div className="flex gap-2 mb-6">
            {["Frete", "+Compra", "Material"].map((tab, i) => (
              <button 
                key={tab}
                className={cn(
                  "flex-1 py-3 rounded-xl text-sm font-bold transition-colors",
                  i === 0 ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"
                )}
              >
                {tab}
              </button>
            ))}
          </div>

          <div className="bg-card rounded-2xl p-4 border border-border space-y-4">
            <h2 className="font-bold text-foreground">Rota</h2>
            <div className="bg-success/10 border border-success/30 rounded-xl p-3 text-xs text-success">
              Distancia automatica ativa
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">Nome do Cliente</label>
                <input 
                  type="text" 
                  placeholder="Ex: Joao Silva"
                  className="w-full h-11 px-4 rounded-xl bg-secondary border-0 text-sm placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">Ponto A - Origem</label>
                <input 
                  type="text" 
                  placeholder="Rua das Flores, 100, Jacarei"
                  className="w-full h-11 px-4 rounded-xl bg-secondary border-0 text-sm placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">Ponto B - Destino</label>
                <input 
                  type="text" 
                  placeholder="Av. Brasil, Sao Jose"
                  className="w-full h-11 px-4 rounded-xl bg-secondary border-0 text-sm placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </div>
            <button className="w-full h-12 rounded-xl bg-chart-2 text-white font-bold">
              CALCULAR DISTANCIA
            </button>
          </div>

          <button className="w-full h-14 rounded-xl bg-primary text-primary-foreground font-bold text-lg">
            GERAR ORCAMENTO
          </button>
        </div>
      </div>
    </div>
  )
}

function MapFullView({ onBack }: { onBack: () => void }) {
  return (
    <div className="min-h-screen">
      <div className="fixed top-4 left-4 z-50">
        <button 
          onClick={onBack} 
          className="glass-dark rounded-full px-4 py-2 text-sm font-bold text-foreground"
        >
          ← Voltar
        </button>
      </div>
      <div className="h-screen bg-secondary">
        <div className="absolute inset-0 flex items-center justify-center">
          <p className="text-muted-foreground">Mapa em tela cheia</p>
        </div>
      </div>
    </div>
  )
}

function HistoryView({ onBack }: { onBack: () => void }) {
  const { profile } = useProfile()
  
  return (
    <div className="min-h-screen p-4 pt-20">
      <div className="max-w-md mx-auto">
        <button onClick={onBack} className="text-sm text-primary mb-4">
          ← Voltar
        </button>
        <h1 className="text-2xl font-black mb-6">Historico</h1>
        
        <div className="space-y-3">
          {[
            { status: "Em andamento", origin: "Centro, Jacarei", dest: "Jardim Satelite", value: 180, date: "Hoje" },
            { status: "Entregue", origin: "Vila Industrial", dest: "Urbanova", value: 220, date: "Ontem" },
            { status: "Entregue", origin: "Parque Res.", dest: "Centro, SJC", value: 150, date: "02/04" },
          ].map((freight, i) => (
            <div key={i} className="bg-card rounded-2xl p-4 border border-border">
              <div className="flex items-center justify-between mb-3">
                <span className={cn(
                  "px-2 py-1 rounded-full text-[10px] font-bold uppercase",
                  freight.status === "Em andamento" 
                    ? "bg-primary/10 text-primary" 
                    : "bg-success/10 text-success"
                )}>
                  {freight.status}
                </span>
                <span className="text-lg font-black">R${freight.value}</span>
              </div>
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-2 h-2 rounded-full bg-primary" />
                  <span className="text-muted-foreground">{freight.origin}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-2 h-2 rounded-full bg-success" />
                  <span className="text-muted-foreground">{freight.dest}</span>
                </div>
              </div>
              <div className="mt-3 pt-3 border-t border-border/50 text-xs text-muted-foreground">
                {freight.date}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

function FinanceView({ onBack }: { onBack: () => void }) {
  return (
    <div className="min-h-screen p-4 pt-20">
      <div className="max-w-md mx-auto">
        <button onClick={onBack} className="text-sm text-primary mb-4">
          ← Voltar
        </button>
        <h1 className="text-2xl font-black mb-6">Financeiro</h1>
        
        <div className="bg-success/10 border border-success/30 rounded-xl p-3 text-xs text-success mb-4">
          Financeiro atualizado automaticamente
        </div>

        <div className="bg-card rounded-2xl p-4 border border-border mb-4">
          <h2 className="font-bold mb-4">Totais - Abril 2026</h2>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Combustivel</span>
              <span className="font-bold text-destructive">R$480,00</span>
            </div>
            <div className="flex justify-between">
              <span className="font-bold">Lucro</span>
              <span className="font-bold text-success text-lg">R$2.770,00</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function TeamView({ onBack }: { onBack: () => void }) {
  return (
    <div className="min-h-screen p-4 pt-20">
      <div className="max-w-md mx-auto">
        <button onClick={onBack} className="text-sm text-primary mb-4">
          ← Voltar
        </button>
        <h1 className="text-2xl font-black mb-6">Equipe</h1>
        
        <div className="space-y-3">
          {[
            { name: "Joao Silva", status: "online", freights: 28, earnings: 4200 },
            { name: "Pedro Santos", status: "online", freights: 22, earnings: 3800 },
            { name: "Carlos Lima", status: "offline", freights: 18, earnings: 2900 },
            { name: "Ana Costa", status: "online", freights: 25, earnings: 4100 },
          ].map((driver, i) => (
            <div key={i} className="bg-card rounded-2xl p-4 border border-border flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={cn(
                  "w-10 h-10 rounded-full flex items-center justify-center font-bold",
                  driver.status === "online" ? "bg-success/20 text-success" : "bg-muted text-muted-foreground"
                )}>
                  {driver.name.charAt(0)}
                </div>
                <div>
                  <p className="font-semibold">{driver.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {driver.freights} fretes · R${driver.earnings.toLocaleString("pt-BR")}
                  </p>
                </div>
              </div>
              <div className={cn(
                "w-3 h-3 rounded-full",
                driver.status === "online" ? "bg-success" : "bg-muted-foreground"
              )} />
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

function ProfileSettingsView({ onBack }: { onBack: () => void }) {
  return (
    <div className="min-h-screen p-4 pt-20">
      <div className="max-w-md mx-auto">
        <button onClick={onBack} className="text-sm text-primary mb-4">
          ← Voltar
        </button>
        <h1 className="text-2xl font-black mb-6">Perfil</h1>
        
        <div className="bg-card rounded-2xl p-6 border border-border text-center mb-4">
          <div className="w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4">
            <span className="text-3xl font-black text-primary">C</span>
          </div>
          <h2 className="text-xl font-bold">Carlos Silva</h2>
          <p className="text-sm text-muted-foreground">carlos@email.com</p>
        </div>

        <div className="space-y-2">
          {["Editar perfil", "Notificacoes", "Privacidade", "Ajuda", "Sair"].map((item, i) => (
            <button 
              key={i}
              className={cn(
                "w-full p-4 rounded-xl bg-card border border-border text-left font-medium transition-colors hover:bg-secondary",
                item === "Sair" && "text-destructive"
              )}
            >
              {item}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}

export default function VapFretesApp() {
  return (
    <ProfileProvider>
      <AppContent />
    </ProfileProvider>
  )
}
